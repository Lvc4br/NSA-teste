import { defineConfig } from "vite";

export default defineConfig({
  base: "/NSA-2.0/",
  build: {
    outDir: "NSA-2.0",
  },
});
